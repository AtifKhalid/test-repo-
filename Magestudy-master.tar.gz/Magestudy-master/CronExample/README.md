# CronExample
Shows how create Cron tasks and Cron groups in Magento 2  
Result in /var/log/.debug.log: "Cron task was started at ..."

License
----
MIT

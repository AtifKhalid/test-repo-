# Widget  
Shows how create simple widget  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/Widget.png "Widget screenshot")  
* Go to CONTENT -> Widgets -> Add Widget
* Select "Magestudy Sample Widget" as type and choose your theme
* Click on continue and fill all fields (in "Widget Options" set some data to label and limit)
* Go to CONTENT -> Pages -> Home Page: add widget to page
* Go to main page for result

License
----
MIT

# CustomerAttribute - Customer  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/CustomerAttribute_GRID.png "CustomerAttribute screenshot")
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/CustomerAttribute_FIELD.png "CustomerAttribute screenshot")
Shows how add new customer (custom) attribute to grid and create/edit form.

License
----
MIT

# ProductExtensionAttribute
Shows how to use Extension Attributes  
Frontend url: .../index.php/ProductExtensionAttribute/hello/index

License
----
MIT
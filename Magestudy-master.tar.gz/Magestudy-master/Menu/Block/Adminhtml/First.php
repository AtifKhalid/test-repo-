<?php

namespace Magestudy\Menu\Block\Adminhtml;

use Magento\Framework\View\Element\Template;

class First extends Template
{

}
<?php

namespace Magestudy\Menu\Block\Adminhtml;

use Magento\Framework\View\Element\Template;

class Second extends Template
{

}
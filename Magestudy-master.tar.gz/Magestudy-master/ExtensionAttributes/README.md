# ExtensionAttributes  
Shows how to use Extension Attributes  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/ExtensionAttribute.png "ExtensionAttributes screenshot")  
Frontend url: .../index.php/ExtensionAttribute/hello/index

License
----
MIT
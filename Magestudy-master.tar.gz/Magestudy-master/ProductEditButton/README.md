# ProductEditButton
Shows how add button to product create/edit page in Magento 2
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/product-edit-button.png "ProductEditButton screenshot")

License
----
MIT

# CustomerEditButton  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/CustomerEditButton.png "CustomerEditButton screenshot")  
Shows how add new button in customer edit page (admin panel).    

License
----
MIT

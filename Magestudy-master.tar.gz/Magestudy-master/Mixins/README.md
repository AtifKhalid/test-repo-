# Mixins  
Shows how to use Mixins in Magento 2:  
* Add new method
* Override method  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/Mixins.png "Mixins screenshot")  
Frontend url: .../index.php/mixin/index

License
----
MIT

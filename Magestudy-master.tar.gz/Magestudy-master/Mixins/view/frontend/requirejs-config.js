var config = {
    config: {
        mixins: {
            'Magestudy_Mixins/js/basic' : {'Magestudy_Mixins/js/basic_mixin':true}
        }
    }
};
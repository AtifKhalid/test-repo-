<?php

namespace Magestudy\LoggerExample\Logger;

class Logger extends \Monolog\Logger
{
}
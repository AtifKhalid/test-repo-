# LoggerExample - Magento 2 extension

###Shows how create custom logger and write data to new file in Magento 2  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/custom_logger.png "LoggerExample screenshot")  
Sample of injection and using here: Magestudy\LoggerExample\Helper\Data

License
----
MIT

# SearchCriteria  
Shows how to configure and create a SearchCriteria instance using the builder for repositories  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/SearchCriteria.png "SearchCriteria screenshot")  
Sample here: Magestudy\SearchCriteria\Controller\Hello\Index.php  
Frontend url: .../index.php/SearchCriteria/hello/index

License
----
MIT

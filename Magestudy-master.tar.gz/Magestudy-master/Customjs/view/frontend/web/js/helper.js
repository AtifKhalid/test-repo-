define([
        'jquery'
    ], function ($) {
        'use strict';

        return {
            sum: function (a, b) {
                return Number(a) + Number(b);
            }
        }
    }
);
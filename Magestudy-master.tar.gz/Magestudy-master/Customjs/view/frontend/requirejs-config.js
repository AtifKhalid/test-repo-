var config = {
    paths: {
        'hello': 'Magestudy_Customjs/js/hello',
        'user': 'Magestudy_Customjs/js/user',
        'helper': 'Magestudy_Customjs/js/helper'
    },
    config: {
        mixins: {
            'Magestudy_Customjs/js/simple_example': {
                'Magestudy_Customjs/js/hook': true
            }
        }
    }
};
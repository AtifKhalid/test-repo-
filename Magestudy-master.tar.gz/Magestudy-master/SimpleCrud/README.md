# SimpleCrud - Simple CRUD for Magento 2   
Shows how create simple CRUD: grid and form (ui component) without deprecated methods  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/SimpleCrudGrid.png "SimpleCrudGrid screenshot")  
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/SimpleCrudForm.png "SimpleCrudForm screenshot")  

License
----
MIT

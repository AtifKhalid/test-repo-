# ConfigExample
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/ConfigExample.png "ConfigExample screenshot")
Show how create and update Configuration in Magento 2 (programmatically)  
In example:
1. New tab
2. Validation
3. Different sections
4. Different fields

Path in admin panel: Menu - Stores - Settings - Configuration - Magestudy example

License
----
MIT

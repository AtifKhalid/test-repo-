# ConsoleCommand
Shows how create console command in Magento 2    
![Sample](https://github.com/nans/devdocs/blob/master/Magestudy/Magestudy_Command.png "ConsoleCommand screenshot")  
Command 1: magestudy:first_test_command  
Command 2: magestudy:fullname FirstName LastName  

License
----
MIT
